import base64
import json
import os
import urllib2
import urlparse
import sys
import zipfile
from os.path import basename, join, normpath, relpath
from cStringIO import StringIO


__version__ = '1.0'

_UPLOAD_LIMIT = 20 * 2**20


class FileSet(object):
    def __init__(self):
        self._data = StringIO()
        zipfile.ZipFile(self._data, 'w', zipfile.ZIP_DEFLATED).close()

    @staticmethod
    def _arcbase(pathname):
        return basename(normpath(pathname))

    def add_file(self, filename, target=None):
        """Add a single file to the FileSet.

        >>> fileset = FileSet()
        >>> fileset.add_file('some/place/file1')
        >>> fileset.add_file('somewhere/else/file2', target='abc/def')
        >>> print '\\n'.join(sorted(fileset.filenames()))
        abc/def
        file1

        :param filename: name of the file to add, as it exists on disk.
        :param target: name (and path) of the file in the FileSet.  Defaults to
            the basename of filename (with no other path components).
        """
        if target is None:
            target = basename(filename)
        with zipfile.ZipFile(self._data, 'a', zipfile.ZIP_DEFLATED) as zf:
            zf.write(filename, arcname=target)

    def add_files(self, filenames, basedir=None):
        """Add multiple files to the FileSet.

        >>> fileset = FileSet()
        >>> fileset.add_files(['abc/file1', 'def/ghi/file2'])
        >>> fileset.add_files(['file3', 'qaz/wsx/file4'], basedir='zzz')
        >>> print '\\n'.join(sorted(fileset.filenames()))
        file1
        file2
        zzz/file3
        zzz/file4

        :param filenames: iterable collection of file names.  Only the basename
            of each filename is used in the FileSet
        :param basedir: directory path to be prepended to each file name in the
            FileSet.  Defaults to nothing (i.e. files added to root directory
            of the FileSet).
        """
        if basedir is None:
            basedir = ''
        with zipfile.ZipFile(self._data, 'a', zipfile.ZIP_DEFLATED) as zf:
            for filename in filenames:
                zf.write(filename, arcname=join(basedir, basename(filename)))

    def add_directory(self, dirname, target=None):
        """Add a single directory and its contents to the FileSet.

        >>> fileset = FileSet()
        >>> # assume some/directory has files f1, f2, f3
        >>> fileset.add_directory('some/directory')
        >>> fileset.add_directory('some/directory', target='another_copy')
        >>> print '\\n'.join(sorted(fileset.filenames()))
        another_copy/f1
        another_copy/f2
        another_copy/f3
        directory/f1
        directory/f2
        directory/f3

        :param dirname: name of the directory to add, as it exists on disk.
        :param target: name of the directory in the FileSet.  Defaults to
            basename of dirname.
        """
        arcbase = self._arcbase(dirname) if target is None else target
        with zipfile.ZipFile(self._data, 'a', zipfile.ZIP_DEFLATED) as zf:
            for path, _, filenames in os.walk(dirname):
                for f in filenames:
                    aname = normpath(join(arcbase, relpath(path, dirname), f))
                    zf.write(join(path, f), aname)

    def add_directories(self, dirnames, basedir=None):
        """Add multiple directories and their contents to the FileSet.

        >>> fileset = FileSet()
        >>> # assume dir1 has files a/f1, a/f2, b/f3; dir2 has files
        >>> # a/f4, b/c/d/e/f5; and dir3 has files c/f6, f7.
        >>> fileset.add_directories(['stuff/dir1', 'dir2'])
        >>> fileset.add_directories(['otherstuff/dir3'], basedir='extra')
        >>> print '\\n'.join(sorted(fileset.filenames()))
        dir1/a/f1
        dir1/a/f2
        dir1/b/f3
        dir2/a/f4
        dir2/b/c/d/e/f5
        extra/dir3/c/f6
        extra/dir3/f7

        :param dirnames: iterable collection of directory names.  Only the
            basename of each directory is used in the FileSet.
        :param basedir: directory path to be prepended to each file added to
            the FileSet.  Defaults to nothing.
        """
        if basedir is None:
            basedir = ''
        with zipfile.ZipFile(self._data, 'a', zipfile.ZIP_DEFLATED) as zf:
            for d in dirnames:
                arcbase = join(basedir, self._arcbase(d))
                for path, _, filenames in os.walk(d):
                    for f in filenames:
                        aname = normpath(join(arcbase, relpath(path, d), f))
                        zf.write(join(path, f), aname)

    def filenames(self):
        with zipfile.ZipFile(self._data, 'r') as zf:
            for zi in zf.infolist():
                yield zi.filename

    def uncompressed_size(self):
        size = 0
        with zipfile.ZipFile(self._data, 'r') as zf:
            for zi in zf.infolist():
                size += zi.file_size
        return size

    def data(self):
        self._data.seek(0)
        return self._data.read()


def _urlopen_with_err_msg(req):
    try:
        return urllib2.urlopen(req)
    except urllib2.HTTPError as e:
        exc_info = sys.exc_info()
        try:
            err_msg = json.load(e)['error_msg']
        except:
            raise exc_info[0], exc_info[1], exc_info[2]
        raise RuntimeError("Request failed: {}".format(err_msg))


class Connection(object):
    def __init__(self, url, token):
        self.url = url.rstrip('/') + '/'
        self._submit_url = urlparse.urljoin(self.url, 'problems/')
        self.token = token
        self._get_headers = {
            'User-Agent': 'dwave_rel/{}'.format(__version__),
            'X-Auth-Token': self.token
        }
        self._post_headers = self._get_headers.copy()
        self._post_headers['Content-Type'] = 'application/json'

    def submit(self, solver_name, fileset, entry_point, params, datasets):
        fs_size = fileset.uncompressed_size()
        if fs_size > _UPLOAD_LIMIT:
            raise ValueError('fileset is too large (size: {size}, '
                             'limit: {limit})'.format(size=fs_size,
                                                      limit=_UPLOAD_LIMIT))
        code = {
            'format': 'py+zip',
            'content': base64.b64encode(fileset.data()),
        }
        data = {
            'solver': solver_name,
            'data': code,
            'type': 'docker',
            'params': {
                'entry_point': entry_point,
                'user_params': params,
                'datasets': datasets,
            }
        }
        request = urllib2.Request(self._submit_url, data=json.dumps([data]),
                                  headers=self._post_headers)
        resp = json.load(_urlopen_with_err_msg(request))[0]
        try:
            job_id = resp['id']
        except KeyError:
            raise RuntimeError("Submission failed: {}".format(
                resp.get('error_msg', '(no error message available)')
            ))
        return SubmittedJob(self, job_id)

    def status(self, job_ids):
        url = urlparse.urljoin(self.url,
                               'problems/?id={}'.format(','.join(job_ids)))
        request = urllib2.Request(url, headers=self._get_headers)
        return json.load(_urlopen_with_err_msg(request))

    def cancel(self, job_id):
        url = urlparse.urljoin(self.url, 'problems/{}/'.format(job_id))
        request = urllib2.Request(url, headers=self._get_headers)
        request.get_method = lambda: 'DELETE'
        return json.load(_urlopen_with_err_msg(request))

    def answer(self, job_id):
        url = urlparse.urljoin(self.url, 'problems/{}/'.format(job_id))
        request = urllib2.Request(url, headers=self._get_headers)
        try:
            return json.load(_urlopen_with_err_msg(request))['answer']
        except KeyError:
            raise RuntimeError("Answer not available")


class SubmittedJob(object):
    def __init__(self, conn, job_id):
        self._conn = conn
        self.job_id = job_id
        self.last_status = None

    def status(self):
        self.last_status = self._conn.status([self.job_id])[0]
        return self.last_status

    def done(self):
        if self.last_status is not None:
            if self.last_status['status'] not in ('PENDING', 'IN_PROGRESS'):
                return True
        return self.status()['status'] not in ('PENDING', 'IN_PROGRESS')

    def cancel(self):
        return self._conn.cancel(self.job_id)

    def answer(self):
        return self._conn.answer(self.job_id)
